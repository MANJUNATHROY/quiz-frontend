import Header from "./Pages/Header/Header";
import "./App.css";
import React from "react";
import axios from "axios";
import { useState, useContext } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import Footer from "./components/Footer/Footer";
// import Header from "./components/Header/Header";
// import Footer from "./Pages/footer/footer";
// import Header from "./Pages/Header/Header";
import Home from "./Pages/Home/Home";
import Quiz from "./Pages/Quiz/Quiz";
import Review from "./Pages/Review/Review";
import Result from "./Pages/Result/Result";
import Scoreboard from "./Pages/Scoreboard/Scoreboard";
import Frm from "./Pages/Form/Form";
import Bookmarklist from "./Pages/Bookmarklist/Bookmarklist";

function App() {
  const [datas, setDatas] = useState("");
  const i = 0;
  const [arr, setArr] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [name, setName] = useState();
  const [score, setScore] = useState(0);
  const fetchdata = [];
  const handleShuffle = (datas) => {
    // return questions.sort(() => Math.random() - 0.5);
    // handleShuffle([questions(questions => [...questions].sort(() => Math.random() - 0.5))]);
    return datas.sort(() => Math.random() - 0.5);
  };

  const fetchQuestions = async (category, subcategory, data) => {
    // const { data } = await axios.get(
    //   // `https://opentdb.com/api.php?amount=10${category && `&category=${category}`}${difficulty && `&difficulty=${difficulty}`}&type=multiple`
    //   // `https://quiz-platform-backend.vercel.app`
    //   `http://localhost:8800/question/question`
    // );
    {
      data.map((input) => {
        if (input.category === category && input.subcategory === subcategory) {
          fetchdata.push(input);
        }
      });
    }
    // setInfo(data);
    console.log(data);
    console.log(fetchdata);
    handleShuffle(fetchdata);
    setQuestions(fetchdata);
    // console.log(questions)
    // setDatas(fetchdata);
  };
  return (
    <div className="app">
      {/* <Header /> */}
      {/* <Router>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                name={name}
                setName={setName}
                fetchQuestions={fetchQuestions}
              />
            }
          />
        </Routes>
        <Routes>
          <Route
            path="/quiz"
            element={
              <Quiz
                name={name}
                questions={questions}
                score={score}
                setScore={setScore}
                setQuestions={setQuestions}
              />
            }
          />
        </Routes>
        <Routes>
          <Route
            path="/result"
            element={<Result name={name} score={score} />}
          />
        </Routes>
        <Routes>
          <Route path="/form" element={<Frm />} />
        </Routes>
        <Routes>
          <Route path="/bookmarklist" element={<Bookmarklist />} />
        </Routes>
        <Routes>
          <Route path="/scoreboard" element={<Scoreboard />} />
        </Routes>
      </Router> */}

      <Router>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                name={name}
                setName={setName}
                fetchQuestions={fetchQuestions}
              />
            }
          />
        </Routes>

        <Routes>
          <Route
            path="/quiz"
            element={
              <Quiz
                name={name}
                arr={arr}
                questions={questions}
                score={score}
                setScore={setScore}
                setQuestions={setQuestions}
                i={i}
              />
            }
          />
        </Routes>
        <Routes>
          <Route
            path="/result"
            element={<Result name={name} score={score} />}
          />
        </Routes>
        <Routes>
          <Route path="/form" element={<Frm />} />
        </Routes>
        <Routes>
          <Route path="/bookmarklist" element={<Bookmarklist />} />
        </Routes>
        <Routes>
          <Route path="/scoreboard" element={<Scoreboard />} />
        </Routes>
        <Routes>
          <Route path="/review" element={<Review arr={arr} />} />
        </Routes>
      </Router>
      <div style={{ textAlign: "center", marginBottom: 10 }}>
        made by{" "}
        <a
          href="https://youtube.com/c/STEAMTroops"
          style={{ cursor: "pointer" }}
        >
          STEAMTroops
        </a>
      </div>
      {/* <Footer /> */}
    </div>
  );
}

export default App;

// import axios from "axios";
// import { useState } from "react";
// import { BrowserRouter, Route, Routes } from "react-router-dom";
// import "./App.css";

// import Home from "./Pages/Home/Home";
// import Quiz from "./Pages/Quiz/Quiz";
// import Result from "./Pages/Result/Result";

// function App() {
//   const [questions, setQuestions] = useState();
//   const [name, setName] = useState();
//   const [score, setScore] = useState(0);

//   const fetchQuestions = async (category = "", difficulty = "") => {
//     const { data } = await axios.get(
//       `https://opentdb.com/api.php?amount=10${category && `&category=${category}`
//       }${difficulty && `&difficulty=${difficulty}`}&type=multiple`
//     );

//     setQuestions(data.results);
//   };

//   return (
//     <BrowserRouter>
//       <div className="app" style={{ backgroundImage: 'url("/ques1.png")' }}>
//         <Header />
//         <Routes>
//           <Route path="/" exact>
//             <Home
//               name={name}
//               setName={setName}
//               fetchQuestions={fetchQuestions}
//             />
//           </Route>
//         </Routes>
//         <Routes>
//           <Route path="/quiz">
//             <Quiz
//               name={name}
//               questions={questions}
//               score={score}
//               setScore={setScore}
//               setQuestions={setQuestions}
//             />
//           </Route>
//         </Routes>
//         <Routes>
//           <Route path="/result">
//             <Result name={name} score={score} />
//           </Route>
//         </Routes>
//       </div>
//       <Footer />
//     </BrowserRouter>
//   );
// }

// export default App;
