const Footer = () => {
	return (
		<div style={{ textAlign: "center", marginBottom: 10 }}>
			made by  {" "}
			<a
				href="https://youtube.com/c/STEAMTroops"
				style={{ cursor: "pointer" }}
			>
				STEAMTroops
			</a>

		</div>
	);
};

export default Footer
