import { Button, TextField } from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import MenuItem from "@mui/material/MenuItem";
import ErrorMessage from "../ErrorMessage/ErrorMessage";
import Scoreboard from "../Scoreboard/Scoreboard";
import axios from "axios";
// import quizlogo from "./Images/quiz.png";

// import Categories from "../Categories/Categories";
// import { Link } from "react-router-dom"
import "./Home.css";
import { Category, CollectionsOutlined } from "@mui/icons-material";

const Home = ({ name, setName, fetchQuestions }) => {
  const navigate = useNavigate();
  const [category, setCategory] = useState([]);
  const [cat, setCat] = useState([]);
  const [data, setData] = useState([]);
  const [error, setError] = useState(false);
  const [subcategory, setSubcategory] = useState([]);
  const [withoutduplicatecat, setWithoutDuplicatecat] = useState([]);
  const [cat2, setCat2] = useState([]);
  useEffect(() => {
    axios.get(`http://localhost:8800/question/question`).then((response) => {
      setData(response.data);
      const cats = response.data.map((q) => q.category);
      // console.log(cats)
      const withoutduplicatecat = [...new Set(cats)];
      // console.log(withoutduplicatecat)

      setCat(withoutduplicatecat);

      // console.log(cat)
      // if(withoutduplicatecat.length>0)
      // {
      //   console.log(withoutduplicatecat)
      //   handlesubcategory(withoutduplicatecat)
      // }
    });
  }, []);

  const handleSubmit = () => {
    if (0) {
      setError(true);
      return;
    } else {
      setError(false);
      fetchQuestions(cat, subcategory);
      navigate("/quiz");
      // <Link to="/quiz" />
    }
  };

  function fetchData(cat, subcat, data) {
    setError(false);
    fetchQuestions(cat, subcat, data);
    navigate("/quiz");
  }

  return (
    <div className="content">
      <div className="settings">
        <div className="settings__select ">
          <div className=" start-quiz box-padding">
            {error && <ErrorMessage>Please Fill all the feilds</ErrorMessage>}
            <TextField
              style={{ marginBottom: 25 }}
              label="Enter Your Name"
              variant="outlined"
              onChange={(e) => setName(e.target.value)}
            />
            <div>
              {cat.map((cat) => {
                if (cat !== "") {
                  const arr1 = [];
                  data.map((subcat) => {
                    if (subcat.category === cat && subcat.subcategory != "") {
                      arr1.push(subcat.subcategory);
                    }
                  });

                  // console.log(arr1)
                  const cat2 = [...new Set(arr1)];
                  //  console.log(arr2)
                  //setCat2(arr2);

                  return (
                    <div>
                      <h2>{cat}</h2>

                      <div className="sub-quiz">
                        {cat2.length &&
                          cat2.map((subcat) => (
                            <div
                              className="quiz-list"
                              type="submit"
                              onClick={() => {
                                fetchData(cat, subcat, data);
                              }}
                            >
                              <div>
                                {" "}
                                <img
                                  className="quiz-list-img"
                                  src="https://img.freepik.com/free-vector/science-word-orange-background-concept_23-2148548239.jpg"
                                  alt=""
                                />
                                {/* <p className="quiz-list-img-tag">{cat}</p> */}
                              </div>
                              <div>
                                <div className="quiz-list-quiz-name">
                                  {subcat}
                                </div>
                                <div className="quiz-list-discp">
                                  <div>Grade: 9-10</div>
                                  <div>15 Ques</div>
                                </div>
                                <div>
                                  {" "}
                                  <button className="quiz-list-btn quiz-list-quiz-btn">
                                    Quiz
                                  </button>
                                  <button className="quiz-list-btn quiz-list-new-btn ">
                                    New
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  );
                }
              })}
            </div>
            {/* <Button
              variant="contained"
              color="primary"
              size="large"
              onClick={handleSubmit}
            >
              Start Quiz
            </Button> */}
            {/* <div>
              {noduplicatecat.map((cat) => (
                <div>
                  <h2>{cat}</h2>
                  <div>
                    <span>
                      <div>
                        <Button>{datas.map((subcat) => {
                          if (subcat.category === cat) {
                            arr1.push(subcat.subcategory)
                          }
                        })}</Button>
                        <Button
                          variant="contained"
                          color="primary"
                          size="large"
                          onClick={handleSubmit}
                        >
                          Start Quiz
                        </Button>
                      </div>
                    </span>
                  </div>
                </div>

              ))}

            </div> */}
            {/* <TextField
              label="Select Category"
              value={cat}
              onChange={(e) => {
                setCat(e.target.value);
              }}
              variant="outlined"
              style={{ marginBottom: 30 }}
            >
              {withoutduplicatecat.map((cat) => {
                if (cat !== "") {
                  return (
                    <MenuItem key={cat} value={cat}>
                      {cat}
                    </MenuItem>
                  );
                }
              })}

            </TextField>

            <TextField
              label="Select subcategory"
              value={subcategory}
              onChange={(e) => {
                setSubCategory(e.target.value);
                console.log(subcategory);
              }}
              variant="outlined"
              style={{ marginBottom: 30 }}
            ></TextField> */}

            {/* <TextField
						select
						label="Select Category"
						value={category}
						onChange={(e) => setCategory(e.target.value)}
						variant="outlined"
						style={{ marginBottom: 30 }}
					>
						{Categories.map((cat) => (
							<MenuItem key={cat.category} value={cat.value}>
								{cat.category}
							</MenuItem>
						))}
					</TextField>
					<TextField
						select
						label="Select Difficulty"
						value={difficulty}
						onChange={(e) => setDifficulty(e.target.value)}
						variant="outlined"
						style={{ marginBottom: 30 }}
					>
						<MenuItem key="Easy" value="easy">
							Easy
						</MenuItem>
						<MenuItem key="Medium" value="medium">
							Medium
						</MenuItem>
						<MenuItem key="Hard" value="hard">
							Hard
						</MenuItem>
					</TextField> */}

            {/* <Button
              variant="contained"
              color="primary"
              size="large"
              onClick={handleSubmit}
            >
              Start Quiz
            </Button> */}
          </div>

          <div className="create-quiz-sidebar box-padding">
            <Button
              variant="contained"
              color="primary"
              size="large"
              href="/form"
            >
              Create Quiz
            </Button>
          </div>
        </div>
      </div>
      <div className="sidebar ">
        <div className="scoreboard-sidebar box-padding">
          <Scoreboard />
        </div>
      </div>
      {/* <img src="https://cdn.riddle.com/website/assets/homepage/img/illo-quiz-types.png" className="banner" alt="quiz app" /> */}
    </div>
  );
};

export default Home;
