// import React from 'react'
// import { useState } from 'react';
import { Button } from 'react-bootstrap';
const Review = ({ arr }) => {
	// const [i, setI] = useState(1);
	console.log(arr)
	console.log("hello")
	return (
		<div>
			{arr.map((ques, i) => {
				if (i < 11) {
					return (
						<div>
							<span>Question {i + 1} <p>{ques.question}</p></span>
							{/* {setI(i + 1)} */}
							<span>correct answer : <p>{ques.correct_answer}</p></span>
							<span>Explanation : <p>{ques.reason}</p></span>
						</div>
					)

				}
			})}<br></br><br></br>
			<div>
				<Button href="/">Go to Homepage</Button>
			</div>
		</div>
	)
}

export default Review;
